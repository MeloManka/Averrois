
---------------------------------------------------------------------------
RESPHEKT FONT
Designed by Evgeny Tkhorzhevsky, http://www.fontfabric.com
Distributed exclusively by www.webdesignerdepot.com and www.mightydeals.com
---------------------------------------------------------------------------

TERMS OF USE:

This product may be used free of charge for personal and/or commercial purposes.

You may not modify, sell or distribute this file on any website, CD-ROM or by any other means whatsoever (including electronic and print distribution), without written consent from Webdesigner Depot. 

If you'd like to share this file with others, please direct them to our website where they can download their copy.

Thanks for supporting our website and enjoy!


Webdesigner Depot
_________________________
www.webdesignerdepot.com
info@webdesignerdepot.com

